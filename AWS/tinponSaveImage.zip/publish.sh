rm ../tinponSaveImage.zip
zip -r ../tinponSaveImage.zip *
cd ..
aws lambda update-function-code --function-name TinponSaveImage --zip-file fileb://tinponSaveImage.zip
