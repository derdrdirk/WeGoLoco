#config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "1269Y5$ST50j"
db_name = "wegoloco"

# arn:aws:iam::037641059503:role/lambda-vpc-execution-role
