var mysql = require('mysql');

var connection = mysql.createConnection({
  host: "wegoloco-cluster.cluster-cb5jwvcwolur.eu-west-1.rds.amazonaws.com",
  user: "admin",
  password: "1269Y5$ST50j"
});

exports.handler = (event, context, callback) => {
  console.log("Lambda started");

  connection.connect(function(err) {
    console.log("inside Connect");
  });

  connection.end();

  console.log("oHoh");
};

generateResponse = (sessionAttributes, speechletResponse) => {
    return {
        version: "1.0",
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    };
};
